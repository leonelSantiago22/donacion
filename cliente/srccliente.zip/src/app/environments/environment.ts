export const environment = {
    production: false,
    //declariacion de la variable global, con el siguiente atributo:
    API_URI: "http://localhost:3000",
    API_URI_CORREOS: "http://localhost:3001",
    API_URI_IMAGENES: "http://localhost:3001"
};
    