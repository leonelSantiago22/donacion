export class Bancos {
    idbanco?: number;
    nombre?:string;
    direccion?: string;
    numeroTelefonico?: number;
     constructor() {
      }
  }
  