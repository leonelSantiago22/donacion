export class Paciente {
    idpaciente?: number;
    idpersona?: number;
    tipodesangre?: string;
    nombre?: string;
    edad?: number;
    genero?: string;
     constructor() {
      
    }
  }
  