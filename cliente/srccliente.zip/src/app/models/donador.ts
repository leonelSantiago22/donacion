export class Donador {
    iddonador?: number;
    idpersona?: number;
    tipodesangre?: string;
    nombre?: string;
    edad?: number;
    genero?: string;
     constructor() {
     
    }
}
  