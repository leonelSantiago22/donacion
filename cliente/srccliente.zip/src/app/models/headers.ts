import { HttpParams, HttpClient, HttpHeaders } from '@angular/common/http';
export const headers = new HttpHeaders().set(
  'Authorization',
  'Bearer eyJhbGciOiJIUzI1NiJ9.ZXJpa3VlQGdtYWlsLmNvbQ.v7atXtnZ9F14ahwqCSjYKQirsvjs5aWQ4MrPz-BCBSk'
);
