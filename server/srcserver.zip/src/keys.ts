export default
{
    database:{
        host: 'localhost',
        user: 'root',
        password: 'x',
        database: 'donacion'
    }
}